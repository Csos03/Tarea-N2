public class Pregunta {
    private String enunciado;
    private String[] opciones;
    private int respuestaCorrecta;
    private int respuestaUsuario = -1;
    private String nivelBloom;
    private String tipoItem;

    public Pregunta(String enunciado, String[] opciones, int respuestaCorrecta, String nivelBloom, String tipoItem) {
        this.enunciado = enunciado;
        this.opciones = opciones;
        this.respuestaCorrecta = respuestaCorrecta;
        this.nivelBloom = nivelBloom;
        this.tipoItem = tipoItem;
    }

    public String getEnunciado() {
        return enunciado;
    }

    public String[] getOpciones() {
        return opciones;
    }

    public int getRespuestaCorrecta() {
        return respuestaCorrecta;
    }

    public String getNivelBloom() {
        return nivelBloom;
    }

    public String getTipoItem() {
        return tipoItem;
    }

    public int getRespuestaUsuario() {
        return respuestaUsuario;
    }

    public void setRespuestaUsuario(int respuestaUsuario) {
        this.respuestaUsuario = respuestaUsuario;
    }

    public boolean esCorrecta() {
        return respuestaUsuario == respuestaCorrecta;
    }
}
