import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;
import java.util.ArrayList;
import java.util.List;


public class Prueba extends JFrame {
    private List<Pregunta> preguntas = new ArrayList<>();
    private int indiceActual = 0;

    private JLabel lblPregunta, lblCantidad, lblTiempo;
    private JRadioButton[] opcionesRadio;
    private ButtonGroup grupoOpciones;
    private JButton btnAtras, btnSiguiente, btnCargarArchivo, btnRevisar;
    private JPanel panelCentro;
    private JFileChooser fileChooser = new JFileChooser();

    public Prueba() {
        setTitle("Sistema de Prueba");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(600, 400);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        lblPregunta = new JLabel("Pregunta");
        lblCantidad = new JLabel("Cantidad de preguntas: 0");
        lblTiempo = new JLabel("Tiempo estimado: 0 min");

        btnCargarArchivo = new JButton("Cargar preguntas desde archivo");
        btnAtras = new JButton("← Atrás");
        btnSiguiente = new JButton("→ Siguiente");
        btnRevisar = new JButton("Revisar respuestas");

        btnCargarArchivo.addActionListener(e -> cargarArchivo());
        btnAtras.addActionListener(e -> mostrarPregunta(indiceActual - 1));
        btnSiguiente.addActionListener(e -> avanzar());
        btnRevisar.addActionListener(e -> revisarRespuestas());

        opcionesRadio = new JRadioButton[4];
        grupoOpciones = new ButtonGroup();
        panelCentro = new JPanel(new GridLayout(6, 1));

        panelCentro.add(lblPregunta);
        for (int i = 0; i < 4; i++) {
            opcionesRadio[i] = new JRadioButton();
            grupoOpciones.add(opcionesRadio[i]);
            panelCentro.add(opcionesRadio[i]);
            final int index = i;
            opcionesRadio[i].addActionListener(e -> preguntas.get(indiceActual).setRespuestaUsuario(index));
        }

        JPanel panelNorte = new JPanel(new GridLayout(2, 1));
        panelNorte.add(btnCargarArchivo);
        panelNorte.add(lblCantidad);

        JPanel panelSur = new JPanel(new FlowLayout());
        panelSur.add(lblTiempo);
        panelSur.add(btnAtras);
        panelSur.add(btnSiguiente);
        panelSur.add(btnRevisar);

        add(panelNorte, BorderLayout.NORTH);
        add(panelCentro, BorderLayout.CENTER);
        add(panelSur, BorderLayout.SOUTH);

        actualizarBotones();
    }

    private void cargarArchivo() {
        int resultado = fileChooser.showOpenDialog(this);
        if (resultado == JFileChooser.APPROVE_OPTION) {
            File archivo = fileChooser.getSelectedFile();
            preguntas = leerPreguntasDesdeArchivo(archivo);
            indiceActual = 0;
            lblCantidad.setText("Cantidad de preguntas: " + preguntas.size());
            lblTiempo.setText("Tiempo estimado: " + (preguntas.size() * 1) + " min");
            mostrarPregunta(0);
        }
    }

    private List<Pregunta> leerPreguntasDesdeArchivo(File archivo) {
        List<Pregunta> lista = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(archivo))) {
            String linea;
            while ((linea = br.readLine()) != null) {
                String[] partes = linea.split("\\|");
                String[] opciones = partes[1].split(",");
                int correcta = Integer.parseInt(partes[2]);
                lista.add(new Pregunta(partes[0], opciones, correcta, partes[3], partes[4]));
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error al leer archivo", "Error", JOptionPane.ERROR_MESSAGE);
        }
        return lista;
    }

    private void mostrarPregunta(int indice) {
        if (indice >= 0 && indice < preguntas.size()) {
            indiceActual = indice;
            Pregunta pregunta = preguntas.get(indiceActual);
            lblPregunta.setText("[" + (indiceActual + 1) + "] " + pregunta.getEnunciado());

            for (int i = 0; i < 4; i++) {
                opcionesRadio[i].setText(pregunta.getOpciones()[i]);
                opcionesRadio[i].setSelected(i == pregunta.getRespuestaUsuario());
            }
            actualizarBotones();
        }
    }

    private void avanzar() {
        if (indiceActual < preguntas.size() - 1) {
            mostrarPregunta(indiceActual + 1);
        } else {
            mostrarResumen();
        }
    }

    private void actualizarBotones() {
        btnAtras.setEnabled(indiceActual > 0);
        btnSiguiente.setText(indiceActual < preguntas.size() - 1 ? "→ Siguiente" : "Enviar respuestas");
    }

    private void mostrarResumen() {
        Map<String, Integer> correctosPorNivel = new HashMap<>();
        Map<String, Integer> totalesPorNivel = new HashMap<>();
        Map<String, Integer> correctosPorTipo = new HashMap<>();
        Map<String, Integer> totalesPorTipo = new HashMap<>();

        for (Pregunta p : preguntas) {
            String nivel = p.getNivelBloom();
            String tipo = p.getTipoItem();

            totalesPorNivel.put(nivel, totalesPorNivel.getOrDefault(nivel, 0) + 1);
            totalesPorTipo.put(tipo, totalesPorTipo.getOrDefault(tipo, 0) + 1);

            if (p.esCorrecta()) {
                correctosPorNivel.put(nivel, correctosPorNivel.getOrDefault(nivel, 0) + 1);
                correctosPorTipo.put(tipo, correctosPorTipo.getOrDefault(tipo, 0) + 1);
            }
        }

        StringBuilder resumen = new StringBuilder("Resumen de Resultados:\n\n");
        resumen.append("Por nivel de Bloom:\n");
        for (String nivel : totalesPorNivel.keySet()) {
            int correctos = correctosPorNivel.getOrDefault(nivel, 0);
            int total = totalesPorNivel.get(nivel);
            resumen.append(String.format("- %s: %.2f%% (%d/%d)\n", nivel, correctos * 100.0 / total, correctos, total));
        }

        resumen.append("\nPor tipo de ítem:\n");
        for (String tipo : totalesPorTipo.keySet()) {
            int correctos = correctosPorTipo.getOrDefault(tipo, 0);
            int total = totalesPorTipo.get(tipo);
            resumen.append(String.format("- %s: %.2f%% (%d/%d)\n", tipo, correctos * 100.0 / total, correctos, total));
        }

        int opcion = JOptionPane.showConfirmDialog(this, resumen.toString(), "Resumen", JOptionPane.OK_CANCEL_OPTION);
        if (opcion == JOptionPane.OK_OPTION) {
            mostrarPregunta(0); // Volver a revisar
        }
    }

    private void revisarRespuestas() {
        StringBuilder sb = new StringBuilder("Revisión de respuestas:\n\n");
        for (int i = 0; i < preguntas.size(); i++) {
            Pregunta p = preguntas.get(i);
            sb.append(String.format("Pregunta %d: %s\n", i + 1, p.getEnunciado()));
            sb.append(String.format("Tu respuesta: %s\n", p.getRespuestaUsuario() == -1 ? "No respondida" : p.getOpciones()[p.getRespuestaUsuario()]));
            sb.append(String.format("Correcta: %s\n", p.getOpciones()[p.getRespuestaCorrecta()]));
            sb.append(String.format("Resultado: %s\n\n", p.esCorrecta() ? "Correcta" : "Incorrecta"));
        }

        JTextArea textArea = new JTextArea(sb.toString(), 20, 50);
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        JOptionPane.showMessageDialog(this, scrollPane, "Revisión detallada", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Prueba().setVisible(true));
    }
}
